
struct {
    bool aimbot = false;
    bool fovawm = false;
    bool selectTarget = false;
    bool silen4a = false;  // Silent aim enabled/disabled - ADDED THIS
    float AimFov = 60;
    float AimDistance = 30;
    bool NoRecoil = false;
    bool aimbotlock = false;
    bool SpeedHackV2 = false;
    bool undercam = false;
    bool PlayerToMe = false;
    float gameSpeed = 1.0f; // ADD THIS LINE
} pPlayer;

struct {
    bool activar = false;
} Actived;